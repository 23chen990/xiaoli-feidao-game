System.register("chunks:///_virtual/builtin-pipeline-settings.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./builtin-pipeline-types.ts"], function (t) {
  var e, o, i, n, r, s, a, p, l, g, c, y, u, m, d, b, h, f;
  return {
    setters: [function (t) {
      e = t.applyDecoratedDescriptor, o = t.inheritsLoose, i = t.initializerDefineProperty, n = t.assertThisInitialized, r = t.createClass;
    }, function (t) {
      s = t.cclegacy, a = t._decorator, p = t.Camera, l = t.CCBoolean, g = t.CCInteger, c = t.CCFloat, y = t.Material, u = t.Texture2D, m = t.rendering, d = t.Component;
    }, function (t) {
      b = t.BloomType, h = t.fillRequiredPipelineSettings, f = t.makePipelineSettings;
    }],
    execute: function execute() {
      var P, _, M, S, w, O, k, E, D, G, B, C, A, j, v, F, x, R, T, I, L, X, z, H, q, Y, N, Q, Z, J, K, U, V;
      s._RF.push({}, "de1c2EHcMhAIYRZY5nyTQHG", "builtin-pipeline-settings", void 0);
      var W = a.ccclass,
        $ = a.disallowMultiple,
        tt = a.executeInEditMode,
        et = a.menu,
        ot = a.property,
        it = a.requireComponent,
        nt = a.type;
      t("BuiltinPipelineSettings", (P = W("BuiltinPipelineSettings"), _ = et("Rendering/BuiltinPipelineSettings"), M = it(p), S = ot(l), w = ot({
        displayName: "Editor Preview (Experimental)",
        type: l
      }), O = ot({
        group: {
          id: "MSAA",
          name: "Multisample Anti-Aliasing"
        },
        type: l
      }), k = ot({
        group: {
          id: "MSAA",
          name: "Multisample Anti-Aliasing",
          style: "section"
        },
        type: g,
        range: [2, 4, 2]
      }), E = ot({
        group: {
          id: "ShadingScale",
          name: "ShadingScale",
          style: "section"
        },
        type: l
      }), D = ot({
        tooltip: "i18n:postprocess.shadingScale",
        group: {
          id: "ShadingScale",
          name: "ShadingScale"
        },
        type: c,
        range: [.01, 4, .01],
        slide: !0
      }), G = ot({
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        },
        type: l
      }), B = nt(b), C = ot({
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        }
      }), A = ot({
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        },
        type: y
      }), j = ot({
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        },
        type: y
      }), v = ot({
        tooltip: "i18n:bloom.enableAlphaMask",
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        },
        type: l
      }), F = ot({
        tooltip: "i18n:bloom.iterations",
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        },
        type: g,
        range: [1, 6, 1],
        slide: !0
      }), x = ot({
        tooltip: "i18n:bloom.threshold",
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        },
        type: c,
        min: 0
      }), R = nt(c), T = ot({
        group: {
          id: "Bloom",
          name: "Bloom (PostProcessing)",
          style: "section"
        }
      }), I = ot({
        group: {
          id: "Color Grading",
          name: "ColorGrading (LDR) (PostProcessing)",
          style: "section"
        },
        type: l
      }), L = ot({
        group: {
          id: "Color Grading",
          name: "ColorGrading (LDR) (PostProcessing)",
          style: "section"
        },
        type: y
      }), X = ot({
        tooltip: "i18n:color_grading.contribute",
        group: {
          id: "Color Grading",
          name: "ColorGrading (LDR) (PostProcessing)",
          style: "section"
        },
        type: c,
        range: [0, 1, .01],
        slide: !0
      }), z = ot({
        tooltip: "i18n:color_grading.originalMap",
        group: {
          id: "Color Grading",
          name: "ColorGrading (LDR) (PostProcessing)",
          style: "section"
        },
        type: u
      }), H = ot({
        group: {
          id: "FXAA",
          name: "Fast Approximate Anti-Aliasing (PostProcessing)",
          style: "section"
        },
        type: l
      }), q = ot({
        group: {
          id: "FXAA",
          name: "Fast Approximate Anti-Aliasing (PostProcessing)",
          style: "section"
        },
        type: y
      }), Y = ot({
        group: {
          id: "FSR",
          name: "FidelityFX Super Resolution",
          style: "section"
        },
        type: l
      }), N = ot({
        group: {
          id: "FSR",
          name: "FidelityFX Super Resolution",
          style: "section"
        },
        type: y
      }), Q = ot({
        group: {
          id: "FSR",
          name: "FidelityFX Super Resolution",
          style: "section"
        },
        type: c,
        range: [0, 1, .01],
        slide: !0
      }), Z = ot({
        group: {
          id: "ToneMapping",
          name: "ToneMapping",
          style: "section"
        },
        type: y
      }), P(J = _(J = M(J = $(J = tt((U = e((K = function (t) {
        function e() {
          for (var e, o = arguments.length, r = new Array(o), s = 0; s < o; s++) r[s] = arguments[s];
          return e = t.call.apply(t, [this].concat(r)) || this, i(e, "_settings", U, n(e)), i(e, "_editorPreview", V, n(e)), e;
        }
        o(e, t);
        var s = e.prototype;
        return s.getPipelineSettings = function () {
          return this._settings;
        }, s.onEnable = function () {
          h(this._settings), this.getComponent(p).camera.pipelineSettings = this._settings;
        }, s.onDisable = function () {
          var t = this.getComponent(p).camera;
          t && (t.pipelineSettings = null);
        }, s._tryEnableEditorPreview = function () {
          void 0 !== m && (this._editorPreview ? m.setEditorPipelineSettings(this._settings) : this._disableEditorPreview());
        }, s._disableEditorPreview = function () {
          void 0 !== m && m.getEditorPipelineSettings() === this._settings && m.setEditorPipelineSettings(null);
        }, r(e, [{
          key: "editorPreview",
          get: function get() {
            return this._editorPreview;
          },
          set: function set(t) {
            this._editorPreview = t;
          }
        }, {
          key: "MsaaEnable",
          get: function get() {
            return this._settings.msaa.enabled;
          },
          set: function set(t) {
            this._settings.msaa.enabled = t;
          }
        }, {
          key: "msaaSampleCount",
          get: function get() {
            return this._settings.msaa.sampleCount;
          },
          set: function set(t) {
            t = Math.pow(2, Math.ceil(Math.log2(Math.max(t, 2)))), t = Math.min(t, 4), this._settings.msaa.sampleCount = t;
          }
        }, {
          key: "shadingScaleEnable",
          get: function get() {
            return this._settings.enableShadingScale;
          },
          set: function set(t) {
            this._settings.enableShadingScale = t;
          }
        }, {
          key: "shadingScale",
          get: function get() {
            return this._settings.shadingScale;
          },
          set: function set(t) {
            this._settings.shadingScale = t;
          }
        }, {
          key: "bloomEnable",
          get: function get() {
            return this._settings.bloom.enabled;
          },
          set: function set(t) {
            this._settings.bloom.enabled = t;
          }
        }, {
          key: "bloomType",
          get: function get() {
            return this._settings.bloom.type;
          },
          set: function set(t) {
            this._settings.bloom.type = t;
          }
        }, {
          key: "kawaseBloomMaterial",
          get: function get() {
            return this._settings.bloom.kawaseFilterMaterial;
          },
          set: function set(t) {
            this._settings.bloom.kawaseFilterMaterial !== t && (this._settings.bloom.kawaseFilterMaterial = t);
          }
        }, {
          key: "mipmapBloomMaterial",
          get: function get() {
            return this._settings.bloom.mipmapFilterMaterial;
          },
          set: function set(t) {
            this._settings.bloom.mipmapFilterMaterial !== t && (this._settings.bloom.mipmapFilterMaterial = t);
          }
        }, {
          key: "bloomEnableAlphaMask",
          get: function get() {
            return this._settings.bloom.enableAlphaMask;
          },
          set: function set(t) {
            this._settings.bloom.enableAlphaMask = t;
          }
        }, {
          key: "bloomIterations",
          get: function get() {
            return this._settings.bloom.iterations;
          },
          set: function set(t) {
            this._settings.bloom.iterations = t;
          }
        }, {
          key: "bloomThreshold",
          get: function get() {
            return this._settings.bloom.threshold;
          },
          set: function set(t) {
            this._settings.bloom.threshold = t;
          }
        }, {
          key: "bloomIntensity",
          get: function get() {
            return this._settings.bloom.intensity;
          },
          set: function set(t) {
            this._settings.bloom.intensity = t;
          }
        }, {
          key: "colorGradingEnable",
          get: function get() {
            return this._settings.colorGrading.enabled;
          },
          set: function set(t) {
            this._settings.colorGrading.enabled = t;
          }
        }, {
          key: "colorGradingMaterial",
          get: function get() {
            return this._settings.colorGrading.material;
          },
          set: function set(t) {
            this._settings.colorGrading.material !== t && (this._settings.colorGrading.material = t);
          }
        }, {
          key: "colorGradingContribute",
          get: function get() {
            return this._settings.colorGrading.contribute;
          },
          set: function set(t) {
            this._settings.colorGrading.contribute = t;
          }
        }, {
          key: "colorGradingMap",
          get: function get() {
            return this._settings.colorGrading.colorGradingMap;
          },
          set: function set(t) {
            this._settings.colorGrading.colorGradingMap = t;
          }
        }, {
          key: "fxaaEnable",
          get: function get() {
            return this._settings.fxaa.enabled;
          },
          set: function set(t) {
            this._settings.fxaa.enabled = t;
          }
        }, {
          key: "fxaaMaterial",
          get: function get() {
            return this._settings.fxaa.material;
          },
          set: function set(t) {
            this._settings.fxaa.material !== t && (this._settings.fxaa.material = t);
          }
        }, {
          key: "fsrEnable",
          get: function get() {
            return this._settings.fsr.enabled;
          },
          set: function set(t) {
            this._settings.fsr.enabled = t;
          }
        }, {
          key: "fsrMaterial",
          get: function get() {
            return this._settings.fsr.material;
          },
          set: function set(t) {
            this._settings.fsr.material !== t && (this._settings.fsr.material = t);
          }
        }, {
          key: "fsrSharpness",
          get: function get() {
            return this._settings.fsr.sharpness;
          },
          set: function set(t) {
            this._settings.fsr.sharpness = t;
          }
        }, {
          key: "toneMappingMaterial",
          get: function get() {
            return this._settings.toneMapping.material;
          },
          set: function set(t) {
            this._settings.toneMapping.material !== t && (this._settings.toneMapping.material = t);
          }
        }]), e;
      }(d)).prototype, "_settings", [ot], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function initializer() {
          return f();
        }
      }), V = e(K.prototype, "_editorPreview", [S], {
        configurable: !0,
        enumerable: !0,
        writable: !0,
        initializer: function initializer() {
          return !1;
        }
      }), e(K.prototype, "editorPreview", [w], Object.getOwnPropertyDescriptor(K.prototype, "editorPreview"), K.prototype), e(K.prototype, "MsaaEnable", [O], Object.getOwnPropertyDescriptor(K.prototype, "MsaaEnable"), K.prototype), e(K.prototype, "msaaSampleCount", [k], Object.getOwnPropertyDescriptor(K.prototype, "msaaSampleCount"), K.prototype), e(K.prototype, "shadingScaleEnable", [E], Object.getOwnPropertyDescriptor(K.prototype, "shadingScaleEnable"), K.prototype), e(K.prototype, "shadingScale", [D], Object.getOwnPropertyDescriptor(K.prototype, "shadingScale"), K.prototype), e(K.prototype, "bloomEnable", [G], Object.getOwnPropertyDescriptor(K.prototype, "bloomEnable"), K.prototype), e(K.prototype, "bloomType", [B, C], Object.getOwnPropertyDescriptor(K.prototype, "bloomType"), K.prototype), e(K.prototype, "kawaseBloomMaterial", [A], Object.getOwnPropertyDescriptor(K.prototype, "kawaseBloomMaterial"), K.prototype), e(K.prototype, "mipmapBloomMaterial", [j], Object.getOwnPropertyDescriptor(K.prototype, "mipmapBloomMaterial"), K.prototype), e(K.prototype, "bloomEnableAlphaMask", [v], Object.getOwnPropertyDescriptor(K.prototype, "bloomEnableAlphaMask"), K.prototype), e(K.prototype, "bloomIterations", [F], Object.getOwnPropertyDescriptor(K.prototype, "bloomIterations"), K.prototype), e(K.prototype, "bloomThreshold", [x], Object.getOwnPropertyDescriptor(K.prototype, "bloomThreshold"), K.prototype), e(K.prototype, "bloomIntensity", [R, T], Object.getOwnPropertyDescriptor(K.prototype, "bloomIntensity"), K.prototype), e(K.prototype, "colorGradingEnable", [I], Object.getOwnPropertyDescriptor(K.prototype, "colorGradingEnable"), K.prototype), e(K.prototype, "colorGradingMaterial", [L], Object.getOwnPropertyDescriptor(K.prototype, "colorGradingMaterial"), K.prototype), e(K.prototype, "colorGradingContribute", [X], Object.getOwnPropertyDescriptor(K.prototype, "colorGradingContribute"), K.prototype), e(K.prototype, "colorGradingMap", [z], Object.getOwnPropertyDescriptor(K.prototype, "colorGradingMap"), K.prototype), e(K.prototype, "fxaaEnable", [H], Object.getOwnPropertyDescriptor(K.prototype, "fxaaEnable"), K.prototype), e(K.prototype, "fxaaMaterial", [q], Object.getOwnPropertyDescriptor(K.prototype, "fxaaMaterial"), K.prototype), e(K.prototype, "fsrEnable", [Y], Object.getOwnPropertyDescriptor(K.prototype, "fsrEnable"), K.prototype), e(K.prototype, "fsrMaterial", [N], Object.getOwnPropertyDescriptor(K.prototype, "fsrMaterial"), K.prototype), e(K.prototype, "fsrSharpness", [Q], Object.getOwnPropertyDescriptor(K.prototype, "fsrSharpness"), K.prototype), e(K.prototype, "toneMappingMaterial", [Z], Object.getOwnPropertyDescriptor(K.prototype, "toneMappingMaterial"), K.prototype), J = K)) || J) || J) || J) || J) || J));
      s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/builtin-pipeline-types.ts", ["cc"], function (e) {
  var a, l, n;
  return {
    setters: [function (e) {
      a = e.cclegacy, l = e.gfx, n = e.ccenum;
    }],
    execute: function execute() {
      e({
        fillRequiredBloom: d,
        fillRequiredColorGrading: p,
        fillRequiredFSR: c,
        fillRequiredFXAA: f,
        fillRequiredHBAO: function fillRequiredHBAO(e) {
          void 0 === e.enabled && (e.enabled = !1);
          void 0 === e.radiusScale && (e.radiusScale = 1);
          void 0 === e.angleBiasDegree && (e.angleBiasDegree = 10);
          void 0 === e.blurSharpness && (e.blurSharpness = 3);
          void 0 === e.aoSaturation && (e.aoSaturation = 1);
          void 0 === e.needBlur && (e.needBlur = !1);
        },
        fillRequiredMSAA: t,
        fillRequiredPipelineSettings: function fillRequiredPipelineSettings(e) {
          e.msaa ? t(e.msaa) : e.msaa = r();
          void 0 === e.enableShadingScale && (e.enableShadingScale = !1);
          void 0 === e.shadingScale && (e.shadingScale = .5);
          e.bloom ? d(e.bloom) : e.bloom = u();
          e.toneMapping ? v(e.toneMapping) : e.toneMapping = {
            material: null
          };
          e.colorGrading ? p(e.colorGrading) : e.colorGrading = {
            enabled: !1,
            material: null,
            contribute: 1,
            colorGradingMap: null
          };
          e.fsr ? c(e.fsr) : e.fsr = {
            enabled: !1,
            material: null,
            sharpness: .8
          };
          e.fxaa ? f(e.fxaa) : e.fxaa = {
            enabled: !1,
            material: null
          };
        },
        fillRequiredToneMapping: v,
        makeBloom: u,
        makeColorGrading: s,
        makeFSR: m,
        makeFXAA: b,
        makeHBAO: function makeHBAO() {
          return {
            enabled: !1,
            radiusScale: 1,
            angleBiasDegree: 10,
            blurSharpness: 3,
            aoSaturation: 1,
            needBlur: !1
          };
        },
        makeMSAA: r,
        makePipelineSettings: function makePipelineSettings() {
          return {
            msaa: r(),
            enableShadingScale: !1,
            shadingScale: .5,
            bloom: u(),
            toneMapping: {
              material: null
            },
            colorGrading: {
              enabled: !1,
              material: null,
              contribute: 1,
              colorGradingMap: null
            },
            fsr: {
              enabled: !1,
              material: null,
              sharpness: .8
            },
            fxaa: {
              enabled: !1,
              material: null
            }
          };
        },
        makeToneMapping: g
      }), a._RF.push({}, "cbf30kCUX9A3K+QpVC6wnzx", "builtin-pipeline-types", void 0);
      var i = l.SampleCount;
      function r() {
        return {
          enabled: !1,
          sampleCount: i.X4
        };
      }
      function t(e) {
        void 0 === e.enabled && (e.enabled = !1), void 0 === e.sampleCount && (e.sampleCount = i.X4);
      }
      var o = e("BloomType", function (e) {
        return e[e.KawaseDualFilter = 0] = "KawaseDualFilter", e[e.MipmapFilter = 1] = "MipmapFilter", e;
      }({}));
      function u() {
        return {
          enabled: !1,
          type: o.KawaseDualFilter,
          material: null,
          kawaseFilterMaterial: null,
          mipmapFilterMaterial: null,
          enableAlphaMask: !1,
          iterations: 3,
          threshold: .8,
          intensity: 1
        };
      }
      function d(e) {
        void 0 === e.enabled && (e.enabled = !1), void 0 === e.type && (e.type = o.KawaseDualFilter), void 0 === e.material && (e.material = null), void 0 === e.kawaseFilterMaterial && (e.kawaseFilterMaterial = e.material || null), void 0 === e.mipmapFilterMaterial && (e.mipmapFilterMaterial = null), void 0 === e.enableAlphaMask && (e.enableAlphaMask = !1), void 0 === e.iterations && (e.iterations = 3), void 0 === e.threshold && (e.threshold = .8), void 0 === e.intensity && (e.intensity = 1);
      }
      function s() {
        return {
          enabled: !1,
          material: null,
          contribute: 1,
          colorGradingMap: null
        };
      }
      function p(e) {
        void 0 === e.enabled && (e.enabled = !1), void 0 === e.material && (e.material = null), void 0 === e.contribute && (e.contribute = 1), void 0 === e.colorGradingMap && (e.colorGradingMap = null);
      }
      function m() {
        return {
          enabled: !1,
          material: null,
          sharpness: .8
        };
      }
      function c(e) {
        void 0 === e.enabled && (e.enabled = !1), void 0 === e.material && (e.material = null), void 0 === e.sharpness && (e.sharpness = .8);
      }
      function b() {
        return {
          enabled: !1,
          material: null
        };
      }
      function f(e) {
        void 0 === e.enabled && (e.enabled = !1), void 0 === e.material && (e.material = null);
      }
      function g() {
        return {
          material: null
        };
      }
      function v(e) {
        void 0 === e.material && (e.material = null);
      }
      n(o), a._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/builtin-pipeline.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./builtin-pipeline-types.ts"], function (e) {
  var a, i, t, r, s, n, o, d, l, h, c, u, p, g, m, S, _, f, w;
  return {
    setters: [function (e) {
      a = e.createForOfIteratorHelperLoose;
    }, function (e) {
      i = e.cclegacy, t = e.geometry, r = e.gfx, s = e.renderer, n = e.Vec2, o = e.Vec4, d = e.macro, l = e.rendering, h = e.assert, c = e.clamp, u = e.Vec3, p = e.Material, g = e.Layers, m = e.PipelineEventType, S = e.sys, _ = e.pipeline;
    }, function (e) {
      f = e.makePipelineSettings, w = e.BloomType;
    }],
    execute: function execute() {
      e("getPingPongRenderTarget", U), i._RF.push({}, "ff9b0GZzgRM/obMbHGfCNbk", "builtin-pipeline", void 0);
      var b = t.AABB,
        P = t.Sphere,
        T = t.intersect,
        R = r.ClearFlagBit,
        M = r.Color,
        v = r.Format,
        E = r.FormatFeatureBit,
        C = r.LoadOp,
        x = r.StoreOp,
        A = r.TextureType,
        L = r.Viewport,
        D = s.scene,
        F = D.CameraUsage,
        N = D.CSMLevel,
        O = D.LightType;
      function B(e) {
        return !!(e.clearFlag & (R.COLOR | R.STENCIL << 1));
      }
      function y(e, a, i, t, r, s) {
        e.shadowFixedArea || e.csmLevel === N.LEVEL_1 ? (r.left = 0, r.top = 0, r.width = Math.trunc(a), r.height = Math.trunc(i)) : (r.left = Math.trunc(t % 2 * .5 * a), r.top = s > 0 ? Math.trunc(.5 * (1 - Math.floor(t / 2)) * i) : Math.trunc(.5 * Math.floor(t / 2) * i), r.width = Math.trunc(.5 * a), r.height = Math.trunc(.5 * i)), r.left = Math.max(0, r.left), r.top = Math.max(0, r.top), r.width = Math.max(1, r.width), r.height = Math.max(1, r.height);
      }
      var Q = e("PipelineConfigs", function () {
        this.isWeb = !1, this.isWebGL1 = !1, this.isWebGL2 = !1, this.isWebGPU = !1, this.isMobile = !1, this.isHDR = !1, this.useFloatOutput = !1, this.toneMappingType = 0, this.shadowEnabled = !1, this.shadowMapFormat = v.R32F, this.shadowMapSize = new n(1, 1), this.usePlanarShadow = !1, this.screenSpaceSignY = 1, this.supportDepthSample = !1, this.mobileMaxSpotLightShadowMaps = 1, this.platform = new o(0, 0, 0, 0);
      });
      function H(e, a) {
        var i = E.SAMPLED_TEXTURE | E.LINEAR_FILTER,
          t = e.device;
        a.isWeb = !S.isNative, a.isWebGL1 = t.gfxAPI === r.API.WEBGL, a.isWebGL2 = t.gfxAPI === r.API.WEBGL2, a.isWebGPU = t.gfxAPI === r.API.WEBGPU, a.isMobile = S.isMobile, a.isHDR = e.pipelineSceneData.isHDR, a.useFloatOutput = e.getMacroBool("CC_USE_FLOAT_OUTPUT"), a.toneMappingType = e.pipelineSceneData.postSettings.toneMappingType;
        var n = e.pipelineSceneData.shadows;
        a.shadowEnabled = n.enabled, a.shadowMapFormat = _.supportsR32FloatTexture(e.device) ? v.R32F : v.RGBA8, a.shadowMapSize.set(n.size), a.usePlanarShadow = n.enabled && n.type === s.scene.ShadowType.Planar, a.screenSpaceSignY = e.device.capabilities.screenSpaceSignY, a.supportDepthSample = (e.device.getFormatFeatures(v.DEPTH_STENCIL) & i) === i;
        var o = t.capabilities.screenSpaceSignY;
        a.platform.x = a.isMobile ? 1 : 0, a.platform.w = .5 * o + .5 << 1 | .5 * t.capabilities.clipSpaceSignY + .5;
      }
      var z = f(),
        I = e("CameraConfigs", function () {
          this.settings = z, this.isMainGameWindow = !1, this.renderWindowId = 0, this.colorName = "", this.depthStencilName = "", this.enableFullPipeline = !1, this.enableProfiler = !1, this.remainingPasses = 0, this.enableShadingScale = !1, this.shadingScale = 1, this.nativeWidth = 1, this.nativeHeight = 1, this.width = 1, this.height = 1, this.enableHDR = !1, this.radianceFormat = r.Format.RGBA8, this.copyAndTonemapMaterial = null, this.enableStoreSceneDepth = !1;
        }),
        W = new M(0, 0, 0, 0);
      function G(e, a, i, t) {
        h(!!i.copyAndTonemapMaterial);
        var r = e.addRenderPass(i.nativeWidth, i.nativeHeight, "cc-tone-mapping");
        return r.addRenderTarget(i.colorName, C.CLEAR, x.STORE, W), r.addTexture(t, "inputTexture"), r.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(i.copyAndTonemapMaterial, 1), r;
      }
      function U(e, a, i) {
        return e.startsWith(a) ? "" + a + (1 - Number(e.charAt(a.length))) + "_" + i : a + "0_" + i;
      }
      var V = function () {
          function e() {
            this.lights = [], this.shadowEnabledSpotLights = [], this._sphere = P.create(0, 0, 0, 1), this._boundingBox = new b(), this._rangedDirLightBoundingBox = new b(0, 0, 0, .5, .5, .5);
          }
          var i = e.prototype;
          return i.cullLights = function (e, i, t) {
            this.lights.length = 0, this.shadowEnabledSpotLights.length = 0;
            for (var r, s = a(e.spotLights); !(r = s()).done;) {
              var n = r.value;
              n.baked || (P.set(this._sphere, n.position.x, n.position.y, n.position.z, n.range), T.sphereFrustum(this._sphere, i) && (n.shadowEnabled ? this.shadowEnabledSpotLights.push(n) : this.lights.push(n)));
            }
            for (var o, d = a(e.sphereLights); !(o = d()).done;) {
              var l = o.value;
              l.baked || (P.set(this._sphere, l.position.x, l.position.y, l.position.z, l.range), T.sphereFrustum(this._sphere, i) && this.lights.push(l));
            }
            for (var h, c = a(e.pointLights); !(h = c()).done;) {
              var p = h.value;
              p.baked || (P.set(this._sphere, p.position.x, p.position.y, p.position.z, p.range), T.sphereFrustum(this._sphere, i) && this.lights.push(p));
            }
            for (var g, m = a(e.rangedDirLights); !(g = m()).done;) {
              var S = g.value;
              b.transform(this._boundingBox, this._rangedDirLightBoundingBox, S.node.getWorldMatrix()), T.aabbFrustum(this._boundingBox, i) && this.lights.push(S);
            }
            t && this.shadowEnabledSpotLights.sort(function (e, a) {
              return u.squaredDistance(t, e.position) - u.squaredDistance(t, a.position);
            });
          }, i._addLightQueues = function (e, i) {
            for (var t, r = a(this.lights); !(t = r()).done;) {
              var s = t.value,
                n = i.addQueue(l.QueueHint.BLEND, "forward-add");
              switch (s.type) {
                case O.SPHERE:
                  n.name = "sphere-light";
                  break;
                case O.SPOT:
                  n.name = "spot-light";
                  break;
                case O.POINT:
                  n.name = "point-light";
                  break;
                case O.RANGED_DIRECTIONAL:
                  n.name = "ranged-directional-light";
                  break;
                default:
                  n.name = "unknown-light";
              }
              n.addScene(e, l.SceneFlags.BLEND, s);
            }
          }, i.addSpotlightShadowPasses = function (e, i, t) {
            for (var r, s = 0, n = a(this.shadowEnabledSpotLights); !(r = n()).done;) {
              var o = r.value,
                d = e.pipelineSceneData.shadows.size,
                h = e.addRenderPass(d.x, d.y, "default");
              if (h.name = "SpotLightShadowPass" + s, h.addRenderTarget("SpotShadowMap" + s, C.CLEAR, x.STORE, new M(1, 1, 1, 1)), h.addDepthStencil("SpotShadowDepth" + s, C.CLEAR, x.DISCARD), h.addQueue(l.QueueHint.NONE, "shadow-caster").addScene(i, l.SceneFlags.OPAQUE | l.SceneFlags.MASK | l.SceneFlags.SHADOW_CASTER).useLightFrustum(o), ++s >= t) break;
            }
          }, i.addLightQueues = function (e, i, t) {
            this._addLightQueues(i, e);
            for (var r, s = 0, n = a(this.shadowEnabledSpotLights); !(r = n()).done;) {
              var o = r.value;
              if (e.addTexture("SpotShadowMap" + s, "cc_spotShadowMap"), e.addQueue(l.QueueHint.BLEND, "forward-add").addScene(i, l.SceneFlags.BLEND, o), ++s >= t) break;
            }
          }, i.addLightPasses = function (e, i, t, r, s, n, o, d, h, c) {
            this._addLightQueues(o, c);
            for (var u, p = 0, g = h.pipelineSceneData.shadows.size, m = a(this.shadowEnabledSpotLights); !(u = m()).done;) {
              var S = u.value,
                _ = h.addRenderPass(g.x, g.y, "default");
              _.name = "SpotlightShadowPass", _.addRenderTarget("ShadowMap" + r, C.CLEAR, x.STORE, new M(1, 1, 1, 1)), _.addDepthStencil("ShadowDepth" + r, C.CLEAR, x.DISCARD), _.addQueue(l.QueueHint.NONE, "shadow-caster").addScene(o, l.SceneFlags.OPAQUE | l.SceneFlags.MASK | l.SceneFlags.SHADOW_CASTER).useLightFrustum(S);
              var f = ++p === this.shadowEnabledSpotLights.length ? t : x.STORE;
              (c = h.addRenderPass(s, n, "default")).name = "SpotlightWithShadowMap", c.setViewport(d), c.addRenderTarget(e, C.LOAD), c.addDepthStencil(i, C.LOAD, f), c.addTexture("ShadowMap" + r, "cc_spotShadowMap"), c.addQueue(l.QueueHint.BLEND, "forward-add").addScene(o, l.SceneFlags.BLEND, S);
            }
            return c;
          }, i.isMultipleLightPassesNeeded = function () {
            return this.shadowEnabledSpotLights.length > 0;
          }, e;
        }(),
        k = e("BuiltinForwardPassBuilder", function () {
          function e() {
            this.forwardLighting = new V(), this._viewport = new L(), this._clearColor = new M(0, 0, 0, 1), this._reflectionProbeClearColor = new u(0, 0, 0);
          }
          var t = e.prototype;
          return t.getConfigOrder = function () {
            return e.ConfigOrder;
          }, t.getRenderOrder = function () {
            return e.RenderOrder;
          }, t.configCamera = function (e, a, i) {
            i.enableMainLightShadowMap = a.shadowEnabled && !a.usePlanarShadow && !!e.scene && !!e.scene.mainLight && e.scene.mainLight.shadowEnabled, i.enableMainLightPlanarShadowMap = a.shadowEnabled && a.usePlanarShadow && !!e.scene && !!e.scene.mainLight && e.scene.mainLight.shadowEnabled, i.enablePlanarReflectionProbe = i.isMainGameWindow || e.cameraUsage === F.SCENE_VIEW || e.cameraUsage === F.GAME_VIEW, i.enableMSAA = i.settings.msaa.enabled && (!a.isWebGL2 || i.remainingPasses > 0 || !d.ENABLE_WEBGL_ANTIALIAS && d.ENABLE_TRANSPARENT_CANVAS) && !i.enableStoreSceneDepth && !a.isWebGL1, i.enableSingleForwardPass = a.isMobile || i.enableMSAA, ++i.remainingPasses;
          }, t.windowResize = function (e, a, i, t, r, s, n) {
            var o = l.ResourceFlags,
              d = l.ResourceResidency,
              h = t.renderWindowId,
              c = i.settings,
              u = i.enableShadingScale ? Math.max(Math.floor(s * i.shadingScale), 1) : s,
              p = i.enableShadingScale ? Math.max(Math.floor(n * i.shadingScale), 1) : n;
            if (i.enableMSAA && (i.enableHDR ? e.addTexture("MsaaRadiance" + h, A.TEX2D, i.radianceFormat, u, p, 1, 1, 1, c.msaa.sampleCount, o.COLOR_ATTACHMENT, d.MEMORYLESS) : e.addTexture("MsaaRadiance" + h, A.TEX2D, v.RGBA8, u, p, 1, 1, 1, c.msaa.sampleCount, o.COLOR_ATTACHMENT, d.MEMORYLESS), e.addTexture("MsaaDepthStencil" + h, A.TEX2D, v.DEPTH_STENCIL, u, p, 1, 1, 1, c.msaa.sampleCount, o.DEPTH_STENCIL_ATTACHMENT, d.MEMORYLESS)), e.addRenderTarget("ShadowMap" + h, a.shadowMapFormat, a.shadowMapSize.x, a.shadowMapSize.y), e.addDepthStencil("ShadowDepth" + h, v.DEPTH_STENCIL, a.shadowMapSize.x, a.shadowMapSize.y), i.enableSingleForwardPass) for (var g = a.mobileMaxSpotLightShadowMaps, m = 0; m !== g; ++m) e.addRenderTarget("SpotShadowMap" + m, a.shadowMapFormat, a.shadowMapSize.x, a.shadowMapSize.y), e.addDepthStencil("SpotShadowDepth" + m, v.DEPTH_STENCIL, a.shadowMapSize.x, a.shadowMapSize.y);
          }, t.setup = function (e, a, i, t, r) {
            e.setVec4("g_platform", a.platform);
            var s = t.window.renderWindowId,
              n = t.scene,
              o = n.mainLight;
            --i.remainingPasses, h(i.remainingPasses >= 0), this.forwardLighting.cullLights(n, t.frustum), i.enableMainLightShadowMap && (h(!!o), this._addCascadedShadowMapPass(e, a, s, o, t)), i.enableSingleForwardPass && this.forwardLighting.addSpotlightShadowPasses(e, t, a.mobileMaxSpotLightShadowMaps), this._tryAddReflectionProbePasses(e, i, s, o, t.scene), i.remainingPasses > 0 || i.enableShadingScale ? (r.colorName = i.enableShadingScale ? "ScaledRadiance0_" + s : "Radiance0_" + s, r.depthStencilName = i.enableShadingScale ? "ScaledSceneDepth_" + s : "SceneDepth_" + s) : (r.colorName = i.colorName, r.depthStencilName = i.depthStencilName);
            var d = this._addForwardRadiancePasses(e, a, i, s, t, i.width, i.height, o, r.colorName, r.depthStencilName, !i.enableMSAA, i.enableStoreSceneDepth ? x.STORE : x.DISCARD);
            return i.enableStoreSceneDepth || (r.depthStencilName = ""), 0 === i.remainingPasses && i.enableShadingScale ? G(e, 0, i, r.colorName) : d;
          }, t._addCascadedShadowMapPass = function (e, a, i, t, r) {
            var s = l.QueueHint,
              n = l.SceneFlags,
              o = e.pipelineSceneData.shadows.size,
              d = o.x,
              h = o.y,
              c = this._viewport;
            c.left = c.top = 0, c.width = d, c.height = h;
            var u = e.addRenderPass(d, h, "default");
            u.name = "CascadedShadowMap", u.addRenderTarget("ShadowMap" + i, C.CLEAR, x.STORE, new M(1, 1, 1, 1)), u.addDepthStencil("ShadowDepth" + i, C.CLEAR, x.DISCARD);
            for (var p = e.pipelineSceneData.csmSupported ? t.csmLevel : 1, g = 0; g !== p; ++g) {
              y(t, d, h, g, this._viewport, a.screenSpaceSignY);
              var m = u.addQueue(s.NONE, "shadow-caster");
              a.isWebGPU || m.setViewport(this._viewport), m.addScene(r, n.OPAQUE | n.MASK | n.SHADOW_CASTER).useLightFrustum(t, g);
            }
          }, t._tryAddReflectionProbePasses = function (e, t, n, o, d) {
            var h = i.internal.reflectionProbeManager;
            if (h) for (var c, u = l.ResourceResidency, p = h.getProbes(), g = 0, m = a(p); !(c = m()).done;) {
              var S = c.value;
              if (S.needRender) {
                var _ = S.renderArea(),
                  f = Math.max(Math.floor(_.x), 1),
                  w = Math.max(Math.floor(_.y), 1);
                if (S.probeType === s.scene.ProbeType.PLANAR) {
                  if (!t.enablePlanarReflectionProbe) continue;
                  var b = S.realtimePlanarTexture.window,
                    P = "PlanarProbeRT" + g,
                    T = "PlanarProbeDS" + g;
                  e.addRenderWindow(P, t.radianceFormat, f, w, b), e.addDepthStencil(T, r.Format.DEPTH_STENCIL, f, w, u.MEMORYLESS);
                  var R = e.addRenderPass(f, w, "default");
                  R.name = "PlanarReflectionProbe" + g, this._buildReflectionProbePass(R, t, n, S.camera, P, T, o, d);
                }
                if (4 === ++g) break;
              }
            }
          }, t._buildReflectionProbePass = function (e, a, i, t, r, s, n, o) {
            void 0 === o && (o = null);
            var d = l.QueueHint,
              h = l.SceneFlags,
              c = a.enableMSAA ? x.DISCARD : x.STORE;
            if (B(t)) {
              this._reflectionProbeClearColor.x = t.clearColor.x, this._reflectionProbeClearColor.y = t.clearColor.y, this._reflectionProbeClearColor.z = t.clearColor.z;
              var u = l.packRGBE(this._reflectionProbeClearColor);
              this._clearColor.x = u.x, this._clearColor.y = u.y, this._clearColor.z = u.z, this._clearColor.w = u.w, e.addRenderTarget(r, C.CLEAR, c, this._clearColor);
            } else e.addRenderTarget(r, C.LOAD, c);
            t.clearFlag & R.DEPTH_STENCIL ? e.addDepthStencil(s, C.CLEAR, x.DISCARD, t.clearDepth, t.clearStencil, t.clearFlag & R.DEPTH_STENCIL) : e.addDepthStencil(s, C.LOAD, x.DISCARD), a.enableMainLightShadowMap && e.addTexture("ShadowMap" + i, "cc_shadowMap"), e.addQueue(d.NONE, "reflect-map").addScene(t, h.OPAQUE | h.MASK | h.REFLECTION_PROBE, n || void 0, o || void 0);
          }, t._addForwardRadiancePasses = function (e, a, i, t, r, s, n, o, d, c, u, p) {
            void 0 === u && (u = !1), void 0 === p && (p = x.DISCARD);
            var g = l.QueueHint,
              m = l.SceneFlags,
              S = r.clearColor;
            this._clearColor.x = S.x, this._clearColor.y = S.y, this._clearColor.z = S.z, this._clearColor.w = S.w;
            var _ = r.viewport;
            this._viewport.left = Math.round(_.x * s), this._viewport.top = Math.round(_.y * n), this._viewport.width = Math.max(Math.round(_.width * s), 1), this._viewport.height = Math.max(Math.round(_.height * n), 1);
            var f = !u && i.enableMSAA;
            h(!f || i.enableSingleForwardPass);
            var w = i.enableSingleForwardPass ? this._addForwardSingleRadiancePass(e, a, i, t, r, f, s, n, o, d, c, p) : this._addForwardMultipleRadiancePasses(e, i, t, r, s, n, o, d, c, p);
            i.enableMainLightPlanarShadowMap && this._addPlanarShadowQueue(r, o, w);
            var b = m.BLEND | (r.geometryRenderer ? m.GEOMETRY : m.NONE);
            return w.addQueue(g.BLEND).addScene(r, b, o || void 0), w;
          }, t._addForwardSingleRadiancePass = function (e, a, i, t, r, s, n, o, d, l, c, u) {
            var p;
            if (h(i.enableSingleForwardPass), s) {
              var g = "MsaaRadiance" + t,
                m = "MsaaDepthStencil" + t,
                S = i.settings.msaa.sampleCount,
                _ = e.addMultisampleRenderPass(n, o, S, 0, "default");
              _.name = "MsaaForwardPass", this._buildForwardMainLightPass(_, i, t, r, g, m, x.DISCARD, d), _.resolveRenderTarget(g, l), p = _;
            } else (p = e.addRenderPass(n, o, "default")).name = "ForwardPass", this._buildForwardMainLightPass(p, i, t, r, l, c, u, d);
            return h(void 0 !== p), this.forwardLighting.addLightQueues(p, r, a.mobileMaxSpotLightShadowMaps), p;
          }, t._addForwardMultipleRadiancePasses = function (e, a, i, t, r, s, n, o, d, l) {
            h(!a.enableSingleForwardPass);
            var c = e.addRenderPass(r, s, "default");
            c.name = "ForwardPass";
            var u = this.forwardLighting.isMultipleLightPassesNeeded() ? x.STORE : l;
            return this._buildForwardMainLightPass(c, a, i, t, o, d, u, n), c = this.forwardLighting.addLightPasses(o, d, l, i, r, s, t, this._viewport, e, c);
          }, t._buildForwardMainLightPass = function (e, a, i, t, r, s, n, o, d) {
            void 0 === d && (d = null);
            var h = l.QueueHint,
              c = l.SceneFlags;
            e.setViewport(this._viewport);
            var u = a.enableMSAA ? x.DISCARD : x.STORE;
            B(t) ? e.addRenderTarget(r, C.CLEAR, u, this._clearColor) : e.addRenderTarget(r, C.LOAD, u), t.clearFlag & R.DEPTH_STENCIL ? e.addDepthStencil(s, C.CLEAR, n, t.clearDepth, t.clearStencil, t.clearFlag & R.DEPTH_STENCIL) : e.addDepthStencil(s, C.LOAD, n), a.enableMainLightShadowMap && e.addTexture("ShadowMap" + i, "cc_shadowMap"), e.addQueue(h.NONE).addScene(t, c.OPAQUE | c.MASK, o || void 0, d || void 0);
          }, t._addPlanarShadowQueue = function (e, a, i) {
            var t = l.QueueHint,
              r = l.SceneFlags;
            i.addQueue(t.BLEND, "planar-shadow").addScene(e, r.SHADOW_CASTER | r.PLANAR_SHADOW | r.BLEND, a || void 0);
          }, e;
        }());
      function Y(e, a) {
        return Math.max(Math.floor(e * a), 1);
      }
      k.ConfigOrder = 100, k.RenderOrder = 100;
      var K = e("BuiltinBloomPassBuilder", function () {
          function e() {
            this._clearColorTransparentBlack = new M(0, 0, 0, 0), this._bloomParams = new o(0, 0, 0, 0), this._bloomTexSize = new o(0, 0, 0, 0), this._bloomWidths = [], this._bloomHeights = [], this._bloomTexNames = [], this._bloomUpSampleTexDescs = [], this._bloomDownSampleTexDescs = [], this._prefilterTexDesc = {
              name: "",
              width: 0,
              height: 0
            }, this._originalColorDesc = {
              name: "",
              width: 0,
              height: 0
            };
          }
          var a = e.prototype;
          return a.getConfigOrder = function () {
            return 0;
          }, a.getRenderOrder = function () {
            return 200;
          }, a.configCamera = function (e, a, i) {
            var t = i.settings.bloom,
              r = t.type === w.KawaseDualFilter && !!t.kawaseFilterMaterial || t.type === w.MipmapFilter && !!t.mipmapFilterMaterial;
            i.enableBloom = t.enabled && r, i.enableBloom && ++i.remainingPasses;
          }, a.windowResize = function (e, a, i, t) {
            if (i.enableBloom) {
              var r = i.width,
                s = i.height,
                n = i.settings.bloom,
                o = t.renderWindowId,
                d = i.radianceFormat;
              if (n.type === w.KawaseDualFilter) for (var l = i.width, h = i.height, c = 0; c !== n.iterations + 1; ++c) l = Math.max(Math.floor(l / 2), 1), h = Math.max(Math.floor(h / 2), 1), e.addRenderTarget("BloomTex" + o + "_" + c, d, l, h);else if (n.type === w.MipmapFilter) {
                for (var u = n.iterations, p = 0; p !== u + 1; ++p) {
                  if (p < u) {
                    var g = Math.pow(.5, p + 2);
                    this._bloomDownSampleTexDescs[p] = this.createTexture(e, "DownSampleColor" + o + p, Y(r, g), Y(s, g), d);
                  }
                  if (p < u - 1) {
                    var m = Math.pow(.5, u - p - 1);
                    this._bloomUpSampleTexDescs[p] = this.createTexture(e, "UpSampleColor" + o + p, Y(r, m), Y(s, m), d);
                  }
                }
                this._originalColorDesc = this.createTexture(e, "OriginalColor" + o, r, s, d), this._prefilterTexDesc = this.createTexture(e, "PrefilterColor" + o, Y(r, .5), Y(s, .5), d);
              }
            }
          }, a.createTexture = function (e, a, i, t, r) {
            var s = {
              name: a,
              width: i,
              height: t
            };
            return e.addRenderTarget(s.name, r, s.width, s.height), s;
          }, a.setup = function (e, a, i, t, r, s) {
            if (!i.enableBloom) return s;
            --i.remainingPasses, h(i.remainingPasses >= 0);
            var n = i.settings.bloom,
              o = t.window.renderWindowId;
            switch (n.type) {
              case w.KawaseDualFilter:
                var d = n.kawaseFilterMaterial;
                return h(!!d), this._addKawaseDualFilterBloomPasses(e, a, i, i.settings, d, o, i.width, i.height, r.colorName);
              case w.MipmapFilter:
                var l = n.mipmapFilterMaterial;
                return h(!!l), this._addMipmapFilterBloomPasses(e, a, i, i.settings, l, o, i.width, i.height, r.colorName);
              default:
                return s;
            }
          }, a._addKawaseDualFilterBloomPasses = function (e, a, i, t, r, s, n, o, d) {
            var h = l.QueueHint,
              c = t.bloom.iterations,
              u = c + 1;
            this._bloomWidths.length = u, this._bloomHeights.length = u, this._bloomWidths[0] = Math.max(Math.floor(n / 2), 1), this._bloomHeights[0] = Math.max(Math.floor(o / 2), 1);
            for (var p = 1; p !== u; ++p) this._bloomWidths[p] = Math.max(Math.floor(this._bloomWidths[p - 1] / 2), 1), this._bloomHeights[p] = Math.max(Math.floor(this._bloomHeights[p - 1] / 2), 1);
            this._bloomTexNames.length = u;
            for (var g = 0; g !== u; ++g) this._bloomTexNames[g] = "BloomTex" + s + "_" + g;
            this._bloomParams.x = a.useFloatOutput ? 1 : 0, this._bloomParams.y = 0, this._bloomParams.z = t.bloom.threshold, this._bloomParams.w = t.bloom.enableAlphaMask ? 1 : 0;
            var m = e.addRenderPass(this._bloomWidths[0], this._bloomHeights[0], "cc-bloom-prefilter");
            m.addRenderTarget(this._bloomTexNames[0], C.CLEAR, x.STORE, this._clearColorTransparentBlack), m.addTexture(d, "inputTexture"), m.setVec4("bloomParams", this._bloomParams), m.addQueue(h.OPAQUE).addFullscreenQuad(r, 0);
            for (var S = 1; S !== u; ++S) {
              var _ = e.addRenderPass(this._bloomWidths[S], this._bloomHeights[S], "cc-bloom-downsample");
              _.addRenderTarget(this._bloomTexNames[S], C.CLEAR, x.STORE, this._clearColorTransparentBlack), _.addTexture(this._bloomTexNames[S - 1], "bloomTexture"), this._bloomTexSize.x = this._bloomWidths[S - 1], this._bloomTexSize.y = this._bloomHeights[S - 1], _.setVec4("bloomTexSize", this._bloomTexSize), _.addQueue(h.OPAQUE).addFullscreenQuad(r, 1);
            }
            for (var f = c; f-- > 0;) {
              var w = e.addRenderPass(this._bloomWidths[f], this._bloomHeights[f], "cc-bloom-upsample");
              w.addRenderTarget(this._bloomTexNames[f], C.CLEAR, x.STORE, this._clearColorTransparentBlack), w.addTexture(this._bloomTexNames[f + 1], "bloomTexture"), this._bloomTexSize.x = this._bloomWidths[f + 1], this._bloomTexSize.y = this._bloomHeights[f + 1], w.setVec4("bloomTexSize", this._bloomTexSize), w.addQueue(h.OPAQUE).addFullscreenQuad(r, 2);
            }
            this._bloomParams.w = t.bloom.intensity;
            var b = e.addRenderPass(n, o, "cc-bloom-combine");
            return b.addRenderTarget(d, C.LOAD, x.STORE), b.addTexture(this._bloomTexNames[0], "bloomTexture"), b.setVec4("bloomParams", this._bloomParams), b.addQueue(h.BLEND).addFullscreenQuad(r, 3), 0 === i.remainingPasses ? G(e, 0, i, d) : b;
          }, a._addPass = function (e, a, i, t, r, s, n, o, d, h) {
            void 0 === o && (o = C.CLEAR), void 0 === d && (d = W), void 0 === h && (h = l.QueueHint.OPAQUE);
            var c = e.addRenderPass(a, i, t);
            return c.addRenderTarget(r, o, x.STORE, d), c.addQueue(h).addFullscreenQuad(s, n), c;
          }, a._addMipmapFilterBloomPasses = function (e, a, i, t, r, s, n, o, d) {
            this._bloomParams.x = a.useFloatOutput ? 1 : 0, this._bloomParams.x = 0, this._bloomParams.z = t.bloom.threshold, this._bloomParams.w = t.bloom.intensity;
            var l = this._prefilterTexDesc,
              h = this._addPass(e, l.width, l.height, "cc-bloom-mipmap-prefilter", l.name, r, 0);
            h.addTexture(d, "mainTexture"), h.setVec4("bloomParams", this._bloomParams);
            for (var c = this._bloomDownSampleTexDescs, u = 0; u < c.length; ++u) {
              var p = c[u],
                g = 0 === u ? l : c[u - 1],
                m = g.name;
              this._bloomTexSize.x = 1 / g.width, this._bloomTexSize.y = 1 / g.height, (h = this._addPass(e, p.width, p.height, "cc-bloom-mipmap-downsample", p.name, r, 1)).addTexture(m, "mainTexture"), h.setVec4("bloomParams", this._bloomTexSize);
            }
            for (var S = c.length - 1, _ = this._bloomUpSampleTexDescs, f = 0; f < _.length; f++) {
              var w = _[f],
                b = 0 === f ? c[S] : _[f - 1],
                P = b.name;
              this._bloomTexSize.x = 1 / b.width, this._bloomTexSize.y = 1 / b.height, (h = this._addPass(e, w.width, w.height, "cc-bloom-mipmap-upsample", w.name, r, 2)).addTexture(P, "mainTexture"), h.addTexture(c[S - 1 - f].name, "downsampleTexture"), h.setVec4("bloomParams", this._bloomTexSize);
            }
            var T = this._addPass(e, n, o, "cc-bloom-mipmap-combine", d, r, 3, C.LOAD);
            return T.addTexture(_[_.length - 1].name, "bloomTexture"), T.setVec4("bloomParams", this._bloomParams), 0 === i.remainingPasses ? G(e, 0, i, d) : T;
          }, e;
        }()),
        X = e("BuiltinToneMappingPassBuilder", function () {
          function e() {
            this._colorGradingTexSize = new n(0, 0);
          }
          var a = e.prototype;
          return a.getConfigOrder = function () {
            return 0;
          }, a.getRenderOrder = function () {
            return 300;
          }, a.configCamera = function (e, a, i) {
            var t = i.settings;
            i.enableColorGrading = t.colorGrading.enabled && !!t.colorGrading.material && !!t.colorGrading.colorGradingMap, i.enableToneMapping = i.enableHDR || i.enableColorGrading, i.enableToneMapping && ++i.remainingPasses;
          }, a.windowResize = function (e, a, i) {
            i.enableColorGrading && (h(!!i.settings.colorGrading.material), i.settings.colorGrading.material.setProperty("colorGradingMap", i.settings.colorGrading.colorGradingMap));
          }, a.setup = function (e, a, i, t, r, s) {
            if (!i.enableToneMapping) return s;
            if (--i.remainingPasses, h(i.remainingPasses >= 0), 0 === i.remainingPasses) return this._addCopyAndTonemapPass(e, a, i, i.width, i.height, r.colorName, i.colorName);
            var n = i.renderWindowId,
              o = i.enableShadingScale ? "ScaledLdrColor" : "LdrColor",
              d = U(r.colorName, o, n),
              l = r.colorName;
            return r.colorName = d, this._addCopyAndTonemapPass(e, a, i, i.width, i.height, l, d);
          }, a._addCopyAndTonemapPass = function (e, a, i, t, r, s, n) {
            var o,
              d = i.settings;
            if (i.enableColorGrading) {
              h(!!d.colorGrading.material), h(!!d.colorGrading.colorGradingMap);
              var c = d.colorGrading.colorGradingMap;
              this._colorGradingTexSize.x = c.width, this._colorGradingTexSize.y = c.height;
              var u = c.width === c.height;
              (o = u ? e.addRenderPass(t, r, "cc-color-grading-8x8") : e.addRenderPass(t, r, "cc-color-grading-nx1")).addRenderTarget(n, C.CLEAR, x.STORE, W), o.addTexture(s, "sceneColorMap"), o.setVec2("lutTextureSize", this._colorGradingTexSize), o.setFloat("contribute", d.colorGrading.contribute), o.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(d.colorGrading.material, u ? 1 : 0);
            } else (o = e.addRenderPass(t, r, "cc-tone-mapping")).addRenderTarget(n, C.CLEAR, x.STORE, W), o.addTexture(s, "inputTexture"), d.toneMapping.material ? o.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(d.toneMapping.material, 0) : (h(!!i.copyAndTonemapMaterial), o.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(i.copyAndTonemapMaterial, 0));
            return o;
          }, e;
        }()),
        q = e("BuiltinFXAAPassBuilder", function () {
          function e() {
            this._fxaaParams = new o(0, 0, 0, 0);
          }
          var a = e.prototype;
          return a.getConfigOrder = function () {
            return 0;
          }, a.getRenderOrder = function () {
            return 400;
          }, a.configCamera = function (e, a, i) {
            i.enableFXAA = i.settings.fxaa.enabled && !!i.settings.fxaa.material, i.enableFXAA && ++i.remainingPasses;
          }, a.setup = function (e, a, i, t, r, s) {
            if (!i.enableFXAA) return s;
            --i.remainingPasses, h(i.remainingPasses >= 0);
            var n = i.renderWindowId,
              o = i.enableShadingScale ? "ScaledLdrColor" : "LdrColor",
              d = U(r.colorName, o, n);
            if (h(!!i.settings.fxaa.material), 0 === i.remainingPasses) return i.enableShadingScale ? (this._addFxaaPass(e, a, i.settings.fxaa.material, i.width, i.height, r.colorName, d), G(e, 0, i, d)) : (h(i.width === i.nativeWidth), h(i.height === i.nativeHeight), this._addFxaaPass(e, a, i.settings.fxaa.material, i.width, i.height, r.colorName, i.colorName));
            var l = r.colorName;
            return r.colorName = d, this._addFxaaPass(e, a, i.settings.fxaa.material, i.width, i.height, l, d);
          }, a._addFxaaPass = function (e, a, i, t, r, s, n) {
            this._fxaaParams.x = t, this._fxaaParams.y = r, this._fxaaParams.z = 1 / t, this._fxaaParams.w = 1 / r;
            var o = e.addRenderPass(t, r, "cc-fxaa");
            return o.addRenderTarget(n, C.CLEAR, x.STORE, W), o.addTexture(s, "sceneColorMap"), o.setVec4("texSize", this._fxaaParams), o.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(i, 0), o;
          }, e;
        }()),
        j = e("BuiltinFsrPassBuilder", function () {
          function e() {
            this._fsrParams = new o(0, 0, 0, 0), this._fsrTexSize = new o(0, 0, 0, 0);
          }
          var a = e.prototype;
          return a.getConfigOrder = function () {
            return 0;
          }, a.getRenderOrder = function () {
            return 500;
          }, a.configCamera = function (e, a, i) {
            i.enableFSR = i.settings.fsr.enabled && !!i.settings.fsr.material && i.enableShadingScale && i.shadingScale < 1, i.enableFSR && ++i.remainingPasses;
          }, a.setup = function (e, a, i, t, r, s) {
            if (!i.enableFSR) return s;
            --i.remainingPasses;
            var n = r.colorName,
              o = 0 === i.remainingPasses ? i.colorName : U(r.colorName, "UiColor", i.renderWindowId);
            return r.colorName = o, h(!!i.settings.fsr.material), this._addFsrPass(e, a, i, i.settings, i.settings.fsr.material, i.renderWindowId, i.width, i.height, n, i.nativeWidth, i.nativeHeight, o);
          }, a._addFsrPass = function (e, a, i, t, r, s, n, o, d, h, u, p) {
            this._fsrTexSize.x = n, this._fsrTexSize.y = o, this._fsrTexSize.z = h, this._fsrTexSize.w = u, this._fsrParams.x = c(1 - t.fsr.sharpness, .02, .98);
            var g = U(p, "UiColor", s),
              m = e.addRenderPass(h, u, "cc-fsr-easu");
            m.addRenderTarget(g, C.CLEAR, x.STORE, W), m.addTexture(d, "outputResultMap"), m.setVec4("fsrTexSize", this._fsrTexSize), m.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(r, 0);
            var S = e.addRenderPass(h, u, "cc-fsr-rcas");
            return S.addRenderTarget(p, C.CLEAR, x.STORE, W), S.addTexture(g, "outputResultMap"), S.setVec4("fsrTexSize", this._fsrTexSize), S.setVec4("fsrParams", this._fsrParams), S.addQueue(l.QueueHint.OPAQUE).addFullscreenQuad(r, 1), S;
          }, e;
        }()),
        Z = e("BuiltinUiPassBuilder", function () {
          function e() {}
          var a = e.prototype;
          return a.getConfigOrder = function () {
            return 0;
          }, a.getRenderOrder = function () {
            return 1e3;
          }, a.setup = function (e, a, i, t, r, s) {
            h(!!s);
            var n = l.SceneFlags.UI;
            return i.enableProfiler && (n |= l.SceneFlags.PROFILER, s.showStatistics = !0), s.addQueue(l.QueueHint.BLEND, "default", "default").addScene(t, n), s;
          }, e;
        }());
      if (l) {
        var J = l.QueueHint,
          $ = l.SceneFlags,
          ee = function () {
            function e() {
              this._pipelineEvent = i.director.root.pipelineEvent, this._forwardPass = new k(), this._bloomPass = new K(), this._toneMappingPass = new X(), this._fxaaPass = new q(), this._fsrPass = new j(), this._uiPass = new Z(), this._clearColor = new M(0, 0, 0, 1), this._viewport = new L(), this._configs = new Q(), this._cameraConfigs = new I(), this._copyAndTonemapMaterial = new p(), this._initialized = !1, this._passBuilders = [];
            }
            var t = e.prototype;
            return t._setupPipelinePreview = function (e, a) {
              if (e.cameraUsage === F.SCENE_VIEW || e.cameraUsage === F.PREVIEW) {
                var i = l.getEditorPipelineSettings();
                a.settings = i || z;
              } else e.pipelineSettings ? a.settings = e.pipelineSettings : a.settings = z;
            }, t._preparePipelinePasses = function (e) {
              var i = this._passBuilders;
              i.length = 0;
              var t = e.settings;
              if (t._passes) {
                for (var r, s = a(t._passes); !(r = s()).done;) {
                  var n = r.value;
                  i.push(n);
                }
                h(i.length === t._passes.length);
              }
              i.push(this._forwardPass), t.bloom.enabled && i.push(this._bloomPass), i.push(this._toneMappingPass), t.fxaa.enabled && i.push(this._fxaaPass), t.fsr.enabled && i.push(this._fsrPass), i.push(this._uiPass);
            }, t._setupBuiltinCameraConfigs = function (e, a, i, t) {
              var s = a.window,
                n = a.cameraUsage === F.GAME && !!s.swapchain,
                o = n || a.cameraUsage === F.GAME_VIEW;
              t.isMainGameWindow = n, t.renderWindowId = s.renderWindowId, t.colorName = s.colorName, t.depthStencilName = s.depthStencilName, t.enableFullPipeline = 0 != (a.visibility & g.Enum.DEFAULT), t.enableProfiler = e.profiler && o, t.remainingPasses = 0, t.shadingScale = t.settings.shadingScale, t.enableShadingScale = t.settings.enableShadingScale && 1 !== t.shadingScale, t.nativeWidth = Math.max(Math.floor(s.width), 1), t.nativeHeight = Math.max(Math.floor(s.height), 1), t.width = t.enableShadingScale ? Math.max(Math.floor(t.nativeWidth * t.shadingScale), 1) : t.nativeWidth, t.height = t.enableShadingScale ? Math.max(Math.floor(t.nativeHeight * t.shadingScale), 1) : t.nativeHeight, t.enableHDR = t.enableFullPipeline && i.useFloatOutput, t.radianceFormat = t.enableHDR ? r.Format.RGBA16F : r.Format.RGBA8, t.copyAndTonemapMaterial = this._copyAndTonemapMaterial, t.enableStoreSceneDepth = !1;
            }, t._setupCameraConfigs = function (e, i, t, r) {
              this._setupPipelinePreview(i, r), this._preparePipelinePasses(r), this._passBuilders.sort(function (e, a) {
                return e.getConfigOrder() - a.getConfigOrder();
              }), this._setupBuiltinCameraConfigs(e, i, t, r);
              for (var s, n = a(this._passBuilders); !(s = n()).done;) {
                var o = s.value;
                o.configCamera && o.configCamera(i, t, r);
              }
            }, t.windowResize = function (e, i, t, r, s) {
              H(e, this._configs), this._setupCameraConfigs(e, t, this._configs, this._cameraConfigs);
              var n = i.renderWindowId;
              e.addRenderWindow(this._cameraConfigs.colorName, v.RGBA8, r, s, i, this._cameraConfigs.depthStencilName);
              var o = this._cameraConfigs.width,
                d = this._cameraConfigs.height;
              this._cameraConfigs.enableShadingScale ? (e.addDepthStencil("ScaledSceneDepth_" + n, v.DEPTH_STENCIL, o, d), e.addRenderTarget("ScaledRadiance0_" + n, this._cameraConfigs.radianceFormat, o, d), e.addRenderTarget("ScaledRadiance1_" + n, this._cameraConfigs.radianceFormat, o, d), e.addRenderTarget("ScaledLdrColor0_" + n, v.RGBA8, o, d), e.addRenderTarget("ScaledLdrColor1_" + n, v.RGBA8, o, d)) : (e.addDepthStencil("SceneDepth_" + n, v.DEPTH_STENCIL, o, d), e.addRenderTarget("Radiance0_" + n, this._cameraConfigs.radianceFormat, o, d), e.addRenderTarget("Radiance1_" + n, this._cameraConfigs.radianceFormat, o, d), e.addRenderTarget("LdrColor0_" + n, v.RGBA8, o, d), e.addRenderTarget("LdrColor1_" + n, v.RGBA8, o, d)), e.addRenderTarget("UiColor0_" + n, v.RGBA8, r, s), e.addRenderTarget("UiColor1_" + n, v.RGBA8, r, s);
              for (var l, h = a(this._passBuilders); !(l = h()).done;) {
                var c = l.value;
                c.windowResize && c.windowResize(e, this._configs, this._cameraConfigs, i, t, r, s);
              }
            }, t.setup = function (e, i) {
              if (!this._initMaterials(i)) for (var t, r = a(e); !(t = r()).done;) {
                var s = t.value;
                s.scene && s.window && (this._setupCameraConfigs(i, s, this._configs, this._cameraConfigs), this._pipelineEvent.emit(m.RENDER_CAMERA_BEGIN, s), this._cameraConfigs.enableFullPipeline ? this._buildForwardPipeline(i, s, s.scene, this._passBuilders) : this._buildSimplePipeline(i, s), this._pipelineEvent.emit(m.RENDER_CAMERA_END, s));
              }
            }, t._buildSimplePipeline = function (e, a) {
              var i = Math.max(Math.floor(a.window.width), 1),
                t = Math.max(Math.floor(a.window.height), 1),
                r = this._cameraConfigs.colorName,
                s = this._cameraConfigs.depthStencilName,
                n = a.viewport;
              this._viewport.left = Math.round(n.x * i), this._viewport.top = Math.round(n.y * t), this._viewport.width = Math.max(Math.round(n.width * i), 1), this._viewport.height = Math.max(Math.round(n.height * t), 1);
              var o = a.clearColor;
              this._clearColor.x = o.x, this._clearColor.y = o.y, this._clearColor.z = o.z, this._clearColor.w = o.w;
              var d = e.addRenderPass(i, t, "default");
              B(a) ? d.addRenderTarget(r, C.CLEAR, x.STORE, this._clearColor) : d.addRenderTarget(r, C.LOAD, x.STORE), a.clearFlag & R.DEPTH_STENCIL ? d.addDepthStencil(s, C.CLEAR, x.DISCARD, a.clearDepth, a.clearStencil, a.clearFlag & R.DEPTH_STENCIL) : d.addDepthStencil(s, C.LOAD, x.DISCARD), d.setViewport(this._viewport), d.addQueue(J.OPAQUE).addScene(a, $.OPAQUE);
              var l = $.BLEND | $.UI;
              this._cameraConfigs.enableProfiler && (l |= $.PROFILER, d.showStatistics = !0), d.addQueue(J.BLEND).addScene(a, l);
            }, t._buildForwardPipeline = function (e, i, t, r) {
              !function (e) {
                e.sort(function (e, a) {
                  return e.getRenderOrder() - a.getRenderOrder();
                });
              }(r);
              for (var s, n = {
                  colorName: "",
                  depthStencilName: ""
                }, o = void 0, d = a(r); !(s = d()).done;) {
                var l = s.value;
                l.setup && (o = l.setup(e, this._configs, this._cameraConfigs, i, n, o));
              }
              h(0 === this._cameraConfigs.remainingPasses);
            }, t._initMaterials = function (e) {
              return this._initialized ? 0 : (H(e, this._configs), this._copyAndTonemapMaterial._uuid = "builtin-pipeline-tone-mapping-material", this._copyAndTonemapMaterial.initialize({
                effectName: "pipeline/post-process/tone-mapping"
              }), this._copyAndTonemapMaterial.effectAsset && (this._initialized = !0), this._initialized ? 0 : 1);
            }, e;
          }();
        l.setCustomPipeline("Builtin", new ee());
      }
      i._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/internal", ["./builtin-pipeline-settings.ts", "./builtin-pipeline-types.ts", "./builtin-pipeline.ts"], function () {
  return {
    setters: [null, null, null],
    execute: function execute() {}
  };
});
(function (r) {
  r('virtual:///prerequisite-imports/internal', 'chunks:///_virtual/internal');
})(function (mid, cid) {
  System.register(mid, [cid], function (_export, _context) {
    return {
      setters: [function (_m) {
        var _exportObj = {};
        for (var _key in _m) {
          if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
        }
        _export(_exportObj);
      }],
      execute: function execute() {}
    };
  });
});