System.register([], function (e) {
  "use strict";

  return {
    execute: function execute() {
      e("default", "assets/bullet.release.wasm-BIzkn7bF.wasm");
    }
  };
});