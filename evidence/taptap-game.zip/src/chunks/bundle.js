function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
System.register([], function (_export, _context) {
  return {
    execute: function execute() {
      System.register("chunks:///_virtual/rollupPluginModLoBabelHelpers.js", [], function (e) {
        return {
          execute: function execute() {
            function r(e, r) {
              for (var t = 0; t < r.length; t++) {
                var n = r[t];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, l(n.key), n);
              }
            }
            function t() {
              return (t = e("extends", Object.assign ? Object.assign.bind() : function (e) {
                for (var r = 1; r < arguments.length; r++) {
                  var t = arguments[r];
                  for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                }
                return e;
              })).apply(this, arguments);
            }
            function n(r, t) {
              return (n = e("setPrototypeOf", Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (e, r) {
                return e.__proto__ = r, e;
              }))(r, t);
            }
            function i(e, r) {
              if (e) {
                if ("string" == typeof e) return o(e, r);
                var t = Object.prototype.toString.call(e).slice(8, -1);
                return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? o(e, r) : void 0;
              }
            }
            function o(e, r) {
              (null == r || r > e.length) && (r = e.length);
              for (var t = 0, n = new Array(r); t < r; t++) n[t] = e[t];
              return n;
            }
            function a(e, r) {
              if ("object" != _typeof(e) || null === e) return e;
              var t = e[Symbol.toPrimitive];
              if (void 0 !== t) {
                var n = t.call(e, r || "default");
                if ("object" != _typeof(n)) return n;
                throw new TypeError("@@toPrimitive must return a primitive value.");
              }
              return ("string" === r ? String : Number)(e);
            }
            function l(e) {
              var r = a(e, "string");
              return "symbol" == _typeof(r) ? r : String(r);
            }
            e({
              applyDecoratedDescriptor: function applyDecoratedDescriptor(e, r, t, n, i) {
                var o = {};
                Object.keys(n).forEach(function (e) {
                  o[e] = n[e];
                }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0);
                o = t.slice().reverse().reduce(function (t, n) {
                  return n(e, r, t) || t;
                }, o), i && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(i) : void 0, o.initializer = void 0);
                void 0 === o.initializer && (Object.defineProperty(e, r, o), o = null);
                return o;
              },
              arrayLikeToArray: o,
              assertThisInitialized: function assertThisInitialized(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
              },
              createClass: function createClass(e, t, n) {
                t && r(e.prototype, t);
                n && r(e, n);
                return Object.defineProperty(e, "prototype", {
                  writable: !1
                }), e;
              },
              createForOfIteratorHelperLoose: function createForOfIteratorHelperLoose(e, r) {
                var t = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (t) return (t = t.call(e)).next.bind(t);
                if (Array.isArray(e) || (t = i(e)) || r && e && "number" == typeof e.length) {
                  t && (e = t);
                  var n = 0;
                  return function () {
                    return n >= e.length ? {
                      done: !0
                    } : {
                      done: !1,
                      value: e[n++]
                    };
                  };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
              },
              "extends": t,
              inheritsLoose: function inheritsLoose(e, r) {
                e.prototype = Object.create(r.prototype), e.prototype.constructor = e, n(e, r);
              },
              initializerDefineProperty: function initializerDefineProperty(e, r, t, n) {
                if (!t) return;
                Object.defineProperty(e, r, {
                  enumerable: t.enumerable,
                  configurable: t.configurable,
                  writable: t.writable,
                  value: t.initializer ? t.initializer.call(n) : void 0
                });
              },
              setPrototypeOf: n,
              toPrimitive: a,
              toPropertyKey: l,
              unsupportedIterableToArray: i
            });
          }
        };
      });
    }
  };
});